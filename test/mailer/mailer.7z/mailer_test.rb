#ActionMailer::Base.server_settings = {
#}
require 'rubygems'
require 'action_mailer'
ActionMailer::Base.raise_delivery_errors = true
ActionMailer::Base.perform_deliveries = true
ActionMailer::Base.default_charset = "utf-8"
ActionMailer::Base.delivery_method = :smtp 
ActionMailer::Base.template_root = File.dirname(__FILE__)
ActionMailer::Base.smtp_settings = {  
 :address => "mail.mchz.com.cn",  
 :port => 25,  
 :authentication => :login,  
 :user_name => "dbra-admin@mchz.com.cn",  
 :password => "dbra-admin",
 :domain => "mchz.com.cn"
} 

class InfoMailer < ActionMailer::Base

  def send(msg,to)
    @subject    = 'DBRA灾备系统通知'
    @body["msg"]  = msg
    @recipients = "#{to}"
    @from       = 'dbra-admin@mchz.com.cn'
    @sent_on    = Time.now.strftime("%Y-%m-%d %H:%M")
    @headers["DBRA system"]    = "杭州美创科技有限公司"
#    content_type "text"
  end
end

#im = InfoMailer.new
InfoMailer.deliver_send("tset action mailer2", "xub@mchz.com.cn")
p "ok"
